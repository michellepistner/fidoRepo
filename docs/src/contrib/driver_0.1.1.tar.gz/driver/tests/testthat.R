library(testthat)
library(driver)

test_check("driver")
