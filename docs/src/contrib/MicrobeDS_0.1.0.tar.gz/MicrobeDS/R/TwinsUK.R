#' @title Genetic Determinants of the Gut Microbiome in UK Twins
#' @details Closed-reference OTU-picking with SortMeRNA (97 percent identity)
#' @description Host genetics and the gut microbiome can both influence host metabolic phenotypes. However, whether host genetic variation shapes the gut microbiome and interacts with it to affect host phenotype is unclear. Here, we addressed this question by comparing microbiotas across more than 1,000 fecal samples obtained from members of the TwinsUK population, including 416 twin-pairs. We identified a variety of microbial taxa whose abundances were influenced by host genetics. The most heritable taxon, the family Christensenellaceae, formed a co-occurrence network with other heritable Bacteria and with methanogenic Archaea, and was enriched in individuals with low BMI. Addition of Christensenella minuta to an obese donor fecal microbiome resulted in reduced weight gain and an altered fecal microbiota in recipient germfree mice. Our findings indicate that host genetics influence the composition of the human gut microbiome and can do so in ways that impact host metabolism.
#' @usage data('TwinsUK')
#' @docType data
#' @source https://qiita.ucsd.edu/study/description/2014
#' @format An object of class \code{"phyloseq"}.
#' @keywords datasets
#' @references Goodrich et al. (2014) Cell. Nov 6;159(4):789-99
#' (\href{https://www.ncbi.nlm.nih.gov/pubmed/25417156}{PubMed})
"TwinsUK"
